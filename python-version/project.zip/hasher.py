from hashlib import sha256, sha1


class Hasher:
    __default_encoding = 'utf-8'

    @staticmethod
    def sha256(_str) -> str:
        return sha256(_str.encode(Hasher.__default_encoding)).hexdigest()

    @staticmethod
    def sha256_bytes(_str):
        return sha256(_str.encode(Hasher.__default_encoding)).digest()

    @staticmethod
    def sha1(_str) -> str:
        return sha1(_str.encode(Hasher.__default_encoding)).hexdigest()
